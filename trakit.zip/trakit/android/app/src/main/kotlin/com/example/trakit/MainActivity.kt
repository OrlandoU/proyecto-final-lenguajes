package com.example.trakit

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
